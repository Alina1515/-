package com.example.organizerapp;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private ArrayList<String> eventsList;
    private ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        eventsList = new ArrayList<>();

        Button addButton = findViewById(R.id.addEventButton);
        ListView eventsListView = findViewById(R.id.eventsListView);

        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, eventsList);
        eventsListView.setAdapter(adapter);

        addButton.setOnClickListener(view -> {
            eventsList.add("Мероприятие " + (eventsList.size() + 1));
            adapter.notifyDataSetChanged();
        });
    }
}
